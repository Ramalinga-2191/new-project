 Micro serive to handle user management curd operations
