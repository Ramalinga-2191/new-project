package com.wipro.usermgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsermgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
